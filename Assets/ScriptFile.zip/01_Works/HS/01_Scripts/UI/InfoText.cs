using UnityEngine;

public class InfoText : MonoBehaviour
{
    public bool isRight;
}
