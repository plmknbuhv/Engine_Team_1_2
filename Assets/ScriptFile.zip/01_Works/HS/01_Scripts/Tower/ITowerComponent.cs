public interface ITowerComponent
{
    public void Initialize(Tower tower);
}
