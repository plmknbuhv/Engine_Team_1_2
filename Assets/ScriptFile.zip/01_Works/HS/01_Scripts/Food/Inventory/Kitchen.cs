using UnityEngine;

public class Kitchen : MonoBehaviour
{

}
